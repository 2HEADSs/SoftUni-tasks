let number = 5;

if (number >= 5) {
    console.log('larger');
} else if (number < 5) {
    console.log('sadasdf');
} else {
    console.log('smaller');
}