let firstName = 'Pesho';
const age = 20;

console.log(firstName + ' - ' + age);

firstName = 'Peter';
// age = 21;
console.log(firstName + ' - ' + age);

if (true) {
    let lastName = 'Petrov';
    var neshto = 'Drugo';
}

console.log(neshto);
