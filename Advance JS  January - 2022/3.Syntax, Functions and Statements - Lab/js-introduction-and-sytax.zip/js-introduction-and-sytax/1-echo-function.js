function solve(input) {
    console.log(input.length);
    console.log(input);
}